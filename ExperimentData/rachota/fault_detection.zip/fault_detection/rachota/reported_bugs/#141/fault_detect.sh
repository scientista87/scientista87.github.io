#!/bin/bash
tool_dir=../../../tool
oracle_file=oracle/oracle_141.xml
testcase_state_dir=Bug_revealing_test_case_state_files
state_property_file=./stateMatrix.properties
tmp_report_Dir=tmpReport



echo "****************************************************************"

for i in `ls $testcase_state_dir/*/*/*.sta`
do
	rm -r $tmp_report_Dir
	mkdir $tmp_report_Dir
	echo $i
	java -jar $tool_dir/fault-detection-state-compare.jar $i $tmp_report_Dir $state_property_file $oracle_file
	echo "****************************************************************"
	rm -r $tmp_report_Dir
done
